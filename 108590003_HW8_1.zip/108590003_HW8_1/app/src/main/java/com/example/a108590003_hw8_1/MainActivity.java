package com.example.a108590003_hw8_1;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

public class MainActivity extends AppCompatActivity {
    private ImageView show;
    private int count = 0;
    private Button bt1;
    private Button bt2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        show = findViewById(R.id.imageView);
        bt1 = findViewById(R.id.button);
        bt2 = findViewById(R.id.button2);
        show.setImageLevel(0);
    }
/*
    public void Sum(View view) {
        bt2.setEnabled(true);
        if(count < 7) {
            count++;
            show.setImageLevel(count);
        }else {
            bt1.setEnabled(false);
        }
    }
    public void Sub(View view){
        bt1.setEnabled(true);
        if(count > 0) {
            count--;
            show.setImageLevel(count);
        }else {
            bt2.setEnabled(false);
        }
    }
 */
    public void changeBatteryLevel(View view) {
        switch (view.getId()){
            case R.id.button2:
                bt1.setEnabled(true);
                if (count > 0){
                    count --;
                    show.setImageLevel(count);
                }else {
                    bt2.setEnabled(false);
                }
                break;
            case R.id.button:
                bt2.setEnabled(true);
                if (count < 7){
                    count ++;
                    show.setImageLevel(count);
                }else {
                    bt1.setEnabled(false);
                }
                break;
            default: break;
        }
    }
}
