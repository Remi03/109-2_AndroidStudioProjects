package com.example.a108590003_hw11_1;

import android.content.Intent;
import android.content.IntentFilter;
import android.support.v4.content.LocalBroadcastManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import java.util.Random;

import static android.content.Intent.ACTION_POWER_CONNECTED;
import static android.content.Intent.ACTION_POWER_DISCONNECTED;

public class MainActivity extends AppCompatActivity {

    private MyBroadcaseReceiver mMyReceiver;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mMyReceiver = new MyBroadcaseReceiver();

        LocalBroadcastManager.getInstance(this).registerReceiver(mMyReceiver, new IntentFilter(ACTION_POWER_CONNECTED));
        LocalBroadcastManager.getInstance(this).registerReceiver(mMyReceiver, new IntentFilter(ACTION_POWER_DISCONNECTED));
        LocalBroadcastManager.getInstance(this).registerReceiver(mMyReceiver, new IntentFilter("ACTION_CUSTOM_BROADCAST"));

    }

    public void onConnected(View view){
        Intent intent = new Intent(ACTION_POWER_CONNECTED);
        LocalBroadcastManager.getInstance(this).sendBroadcast(intent);

    }

    public void onDisconnected(View view){
        Intent intent = new Intent(ACTION_POWER_DISCONNECTED);
        LocalBroadcastManager.getInstance(this).sendBroadcast(intent);

    }

    public void onBroadcast(View view){
        Random r = new Random();
        int num = r.nextInt(20);
        Intent intent = new Intent("ACTION_CUSTOM_BROADCAST");
        intent.putExtra("Number",num);
        LocalBroadcastManager.getInstance(this).sendBroadcast(intent);

    }

    @Override
    protected void onDestroy(){
        LocalBroadcastManager.getInstance(this).unregisterReceiver(mMyReceiver);
        super.onDestroy();
    }

}