package com.example.a108590003_hw7_2;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class food3 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_food3);
    }
}