package com.example.a108590003_hw9_1;


import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

public class food2 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_food2);
    }
}