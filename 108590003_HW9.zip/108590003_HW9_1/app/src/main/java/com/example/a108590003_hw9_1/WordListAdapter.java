package com.example.a108590003_hw9_1;

import android.content.Context;
import android.content.Intent;
//import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
//import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import java.util.LinkedList;

public class WordListAdapter extends RecyclerView.Adapter<WordListAdapter.WordViewHolder> {
    private final LinkedList<String> mWordList;
    private final LinkedList<String> mContainList;
    private final LayoutInflater mInflater;

    class WordViewHolder extends RecyclerView.ViewHolder
            implements View.OnClickListener {
        public final TextView wordItemView;
        public final TextView containItemView;
        final WordListAdapter mAdapter;

        public WordViewHolder(View itemView, WordListAdapter adapter) {
            super(itemView);
            wordItemView = itemView.findViewById(R.id.title);
            containItemView=itemView.findViewById(R.id.content);
            this.mAdapter = adapter;
            itemView.setOnClickListener(this);
        }

        @Override
        public void onClick(View view) {
            // Get the position of the item that was clicked.
            int mPosition = getLayoutPosition();

            // Use that to access the affected item in mWordList.
            String element = mWordList.get(mPosition);
            // Change the word in the mWordList.
            //mWordList.set(mPosition, "Clicked! " + element);
            if(mPosition == 0){
                Intent intent = new Intent(view.getContext(),food1.class);
                view.getContext().startActivity(intent);
            }
            else if(mPosition == 1){
                Intent intent = new Intent(view.getContext(),food2.class);
                view.getContext().startActivity(intent);
            }
            else if(mPosition == 2){
                Intent intent = new Intent(view.getContext(),food3.class);
                view.getContext().startActivity(intent);
            }
            else if(mPosition == 3){
                Intent intent = new Intent(view.getContext(),food4.class);
                view.getContext().startActivity(intent);
            }
            else if(mPosition == 4){
                Intent intent = new Intent(view.getContext(),food5.class);
                view.getContext().startActivity(intent);
            }
            else if(mPosition == 5){
                Intent intent = new Intent(view.getContext(),food6.class);
                view.getContext().startActivity(intent);
            }
//            else if(mPosition == 6){
//                Intent intent = new Intent(view.getContext(),food7.class);
//                view.getContext().startActivity(intent);
//            }
            mAdapter.notifyDataSetChanged();
        }
    }

    public WordListAdapter(Context context, LinkedList<String> wordList, LinkedList<String> containList) {
        mInflater = LayoutInflater.from(context);
        this.mWordList = wordList;
        this.mContainList=containList;
    }

    @Override
    public WordListAdapter.WordViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        // Inflate an item view.
        View mItemView = mInflater.inflate(R.layout.activity_word_list_adapter, parent, false);
        return new WordViewHolder(mItemView, this);
    }

    @Override
    public void onBindViewHolder(WordListAdapter.WordViewHolder holder, int position) {
        // Retrieve the data for that position.
        String mCurrent = mWordList.get(position);
        String mCurrent2=mContainList.get(position);
        // Add the data to the view holder.
        holder.wordItemView.setText(mCurrent);
        holder.containItemView.setText(mCurrent2);
    }

    @Override
    public int getItemCount() {
        return mWordList.size();
    }

}