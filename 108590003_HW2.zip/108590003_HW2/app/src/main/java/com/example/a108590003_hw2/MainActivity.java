package com.example.a108590003_hw2;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private int mCount = 0;
    private int countToast = 0;
    private int count_Up = 0;
    private TextView mShowCount;
    private Button btnToast;
    private Button btnZero;
    private Button btnUp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mShowCount = (TextView) findViewById(R.id.textView);
        btnToast = (Button) findViewById(R.id.button);
        btnZero = (Button) findViewById(R.id.button2);
        btnUp = (Button) findViewById(R.id.button3);
    }

    public void showToast(View view) {
        Toast toast = Toast.makeText(this, R.string.toast_message,
                Toast.LENGTH_SHORT);
        toast.show();
        if(countToast%2==0) {
            btnToast.setBackgroundColor(0xFF5F9F9F);
        }
        else {
            btnToast.setBackgroundColor(0xFF5C3317);
        }
        countToast++;
    }

    public void countUp(View view) {
        mCount++;
        if (mShowCount != null)
            mShowCount.setText(Integer.toString(mCount));
        if(count_Up%2== 0){
            btnUp.setBackgroundColor(0xFF215E21);
        }
        else{
            btnUp.setBackgroundColor(0xFF38B0DE);
        }
        count_Up++;
        btnZero.setBackgroundColor(0xFFFF2400);
        btnZero.setEnabled(true);
    }
    public void counZero(View view) {
        mCount = 0;
        if (mShowCount != null)
            mShowCount.setText(Integer.toString(mCount));
        btnZero.setBackgroundColor(Color.GRAY);
        btnZero.setEnabled(false);
    }
}