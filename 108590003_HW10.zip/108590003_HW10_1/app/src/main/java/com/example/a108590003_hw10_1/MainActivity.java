package com.example.a108590003_hw10_1;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    private TextView c_TextView;
    private ProgressBar c_ProgressBar;
    private static final String TEXT_STATE = "CurrentText";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        c_TextView = findViewById(R.id.textView);
        c_ProgressBar = findViewById(R.id.progressBar);

        if (savedInstanceState != null){
            c_TextView.setText(savedInstanceState.getString(TEXT_STATE));
        }

    }

    public void startTask(View view){
        c_TextView.setText("Napping...");
        new SimpleAsyncTask(c_TextView,c_ProgressBar).execute();
    }

    @Override
    protected void onSaveInstanceState(Bundle outState){
        super.onSaveInstanceState(outState);
        outState.putString(TEXT_STATE,c_TextView.getText().toString());
    }
}