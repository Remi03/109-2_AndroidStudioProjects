package com.example.a108590003_hw10_1;

import android.content.Intent;
import android.os.AsyncTask;
import android.widget.ProgressBar;
import android.widget.TextView;

import java.lang.ref.WeakReference;
import java.util.Random;

public class SimpleAsyncTask extends AsyncTask<Void, Integer, String> {
    private WeakReference<TextView> c_TextView;
    private WeakReference<ProgressBar> c_ProgressBar;
    private static final int CHUNK_SIZE = 7;


    SimpleAsyncTask (TextView tv, ProgressBar bar){
        c_TextView = new WeakReference<>(tv);
        c_ProgressBar = new WeakReference<>(bar);
    }

    @Override
    protected String doInBackground(Void... voids) {
        Random random = new Random();
        int number = random.nextInt(11);
        int milli = number * 700;
        int chunkSize = milli / CHUNK_SIZE;
        for (int i = 0; i < CHUNK_SIZE; i++){
            try {
                Thread.sleep(chunkSize);
            }
            catch (InterruptedException e){
                e.printStackTrace();
            }
            publishProgress(((i + 1) * 100) / CHUNK_SIZE);
        }

        return "Awake after sleeping for " + milli + " milliseconds";
    }

    @Override
    protected void onProgressUpdate(Integer... values) {
        c_ProgressBar.get().setProgress(values[0]);

    }

    @Override
    protected void onPostExecute(String result) {
        c_TextView.get().setText(result);
    }
}
