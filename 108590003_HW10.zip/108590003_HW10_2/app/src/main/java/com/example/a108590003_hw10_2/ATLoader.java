package com.example.a108590003_hw10_2;

import android.content.Context;
import android.support.annotation.Nullable;
import android.support.v4.content.AsyncTaskLoader;

import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

public class ATLoader extends AsyncTaskLoader<String> {
    private String c_Receive;
    private HttpURLConnection c_url;
    private String content;


    public ATLoader(Context context, String queryString) {
        super(context);
        c_Receive = queryString;
    }

    @Override
    protected void onStartLoading(){
        super.onStartLoading();

        forceLoad();
    }


    @Nullable
    @Override
    public String loadInBackground() {
        try {
            // 定義訪問URL
            URL url = new URL(c_Receive);
            // 獲取指定URL 的 httpurlconnection 物件，用於傳送或接收資料
            c_url = (HttpURLConnection) url.openConnection();
            // 設定連線超時時間，單位預設為毫秒
            c_url.setConnectTimeout(5000);
            // 設定請求方式
            c_url.setRequestMethod("GET");

            try {
                // 獲取狀態碼
                int url_status = c_url.getResponseCode();
                System.out.println("狀態碼為：" + url_status);
                // 狀態碼判定服務訪問狀態
                if (url_status == 200) {
                    // 獲取訪問資料輸入資料流
                    InputStream in = c_url.getInputStream();
                    // 使用定義的工具類把 輸入流轉化為字串
                    content = MainActivity.instreamTOstr.readStream(in);
                    System.out.println(content);
                }
            } catch (IOException e) {
                e.printStackTrace();
            }

            // 在主執行緒中設定輸出到文字檢視中
        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return content;
    }
}
