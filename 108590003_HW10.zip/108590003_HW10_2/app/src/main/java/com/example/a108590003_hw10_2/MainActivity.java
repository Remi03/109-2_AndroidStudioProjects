package com.example.a108590003_hw10_2;

import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.LoaderManager;
import android.support.v4.content.Loader;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;

public class MainActivity extends AppCompatActivity implements LoaderManager.LoaderCallbacks<String> {
    private TextView c_TextView;
    private Spinner c_Spinner;
    private EditText c_EditText;
    private String header;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        c_TextView=(TextView)findViewById(R.id.textView2);
        c_Spinner=(Spinner)findViewById(R.id.spinner);
        c_EditText=(EditText)findViewById(R.id.editTextTextPersonName);
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,R.array.item, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        c_Spinner.setAdapter(adapter);
        c_Spinner.setOnItemSelectedListener(onInput);
        getSupportLoaderManager().initLoader(0,null,this);
    }

    private AdapterView.OnItemSelectedListener onInput = new AdapterView.OnItemSelectedListener() {
        public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
            Toast.makeText(getApplicationContext(), parent.getItemAtPosition(position).toString(), Toast.LENGTH_SHORT).show();
            header = parent.getItemAtPosition(position).toString();
        }
        public void onNothingSelected(AdapterView<?> parent) {

        }
    };

    @NonNull
    @Override
    public Loader<String> onCreateLoader(int i, @Nullable Bundle bundle) {
        return new ATLoader(this, header+c_EditText.getText().toString());
    }

    @Override
    public void onLoadFinished(@NonNull Loader<String> loader, String s) {
        c_TextView.setText(s);
    }

    @Override
    public void onLoaderReset(@NonNull Loader<String> loader) {

    }

    public void onSearch(View view){
        Bundle queryBundle = new Bundle();
        queryBundle.putString("queryString", header+c_EditText.getText().toString());
        getSupportLoaderManager().restartLoader(0, queryBundle, this);
    }

    public static class instreamTOstr {

        public static String readStream(InputStream in) throws IOException {
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            int len = -1;
            byte[] buffer = new byte[1024];
            while ((len = in.read(buffer))!=-1){
                baos.write(buffer,0,len);
            }
            in.close();
            String content = new String(baos.toByteArray());
            return content;
        }
    }

}
