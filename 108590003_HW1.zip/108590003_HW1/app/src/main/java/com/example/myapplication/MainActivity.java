package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Log.v("MainActivity","123778");
        Log.d("MainActivity","123778");
        Log.i("MainActivity","123778");
        Log.w("MainActivity","123778");
        Log.e("MainActivity","123778");
    }
}